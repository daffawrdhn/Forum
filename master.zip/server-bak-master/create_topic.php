<!DOCTYPE html>
<html lang="en">
<?php
//Including the functions.php-file so that the page gets access to the functions it needs.
include_once('header.php');
include_once('functions.php');
?>
<head>
<title>
	Forum
</title>
<meta charset="utf-8">
<meta name="viewport"content="width=device-width, initial-scale=1">
<link href="css/bootstrap.min.css" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

<script>
//JS function for displaying and hiding the login form
	function showLogin(){
		if($('#login').is(":visible")){
			$('#login').slideUp();
		}else{$('#login').slideDown();}

	}
//The url is checked for specific data. If spesific values are found the user is given an error message via an alert.
	$(document).ready(function(){
		if(window.location.href.indexOf("UNF") > -1){
			alert("Login failed: User not found");
		}else if(window.location.href.indexOf("UAT") > -1){
			alert("Username is already taken");
		}else if(window.location.href.indexOf("TFF=false") > -1){
			alert("Please fill all text boxes when creating a new topic");
		}else if(window.location.href.indexOf("PFF") > -1){
			alert("Please fill all inputfields.");
		}else if(window.location.href.indexOf("RFF=false") > -1){
			alert("All registration fields have to be filled");
		}else if(window.location.href.indexOf("ITL") > -1){
			alert("Input exceeds maximum length.");
		}else if(window.location.href.indexOf("ICD") > -1){
			alert("Username and password can't contain special characters..");
		}
	});
//JS function for creating or displaying the form used to update comments.
	function showEdit(pID, rID, tID){
		if($("#form"+rID).length){
			if($("#form"+rID).is(":visible")){
				$("#form"+rID).slideUp();
			}else{$("#form"+rID).slideDown();}

		}else{
			if(pID != -1){
				$("#row"+rID).append("<br><form id='form"+rID+"' class='forms' action='functions.php' method='post'>"
						+"<textarea name='updCont' placeholder='Updated comment'></textarea><br>"
						+"<input type='hidden' name='postID' value='"+pID+"'>"
						+"<input type='hidden' name='topicID' value='"+tID+"'>"
						+"<button type='submit' name='submit' value='updContent'>Update comment</button> "
						+"<button type='submit' name='submit' value='delContent' onClick=\"return confirm('Are you sure?')\">"
						+"Delete comment</button>"
						+"</form>");
				$("#form"+rID).slideDown();
			}else{
				$("#row"+rID).append("<br><form class='forms' id='form"+rID+"' action='functions.php' method='post'>"
						+"<textarea name='updCont' placeholder='Updated description'></textarea><br>"
//The pID has a value of -1 and is used for identifying it as different type of content.
						+"<input type='hidden' name='postID' value='"+pID+"'>"
						+"<input type='hidden' name='topicID' value='"+tID+"'>"
						+"<button type='submit' name='submit' value='updContent'>Update</button> "
						+"</form>");
				$("#form"+rID).slideDown();
			}

		}

	}
</script>
</head>
<body>

<div id="content">
	<div class="float-none">
		<div class="">
			<?php
			//If the page is given a value 't' we display a single topic and its comments.
				if(isset($_GET["t"])){
					printTopic($_GET["t"]);
				//If 't' isn't found the page instead displays all topics.
				}else{printTopics();}


			?>
		</div>
	</div>
</div>
</body>
</html>
