<style media="screen">
#page-content {
flex: 1 0 auto;
}

#sticky-footer {
flex-shrink: none;
}
</style>

<body class="d-flex flex-column">
  <footer id="sticky-footer" class="py-4 bg-dark text-dark-50">
    <div class="container text-center">
      <small>Copyright &copy; wrdhndty.site</small>
    </div>
  </footer>
</body>
