<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
      <style media="screen">
        table, th, td, tr {
          border: 1px solid black;
          }
      </style>
  </head>
  <body>
    <table id="1">
      <tr>
          <td>
            <h3>
              <a>test</a>
            </h3>
            <p>test</p>
          </td>
        </tr>
    </table>

    <br><br>

    <table id="2">
      <tr>
        <th>author</th>
        <th>title</th>
      </tr>
      <tr>
        <td>Peter</td>
      </tr>
      <tr>
        <td>Lois</td>
      </tr>
    </table>
  </body>

</html>
