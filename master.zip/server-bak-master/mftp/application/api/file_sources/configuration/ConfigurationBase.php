<?php

    interface ConfigurationBase {
        public function getRemoteUsername();
    }